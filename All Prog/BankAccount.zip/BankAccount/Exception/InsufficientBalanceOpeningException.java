package com.cg.BankAccount.Exception;

public class InsufficientBalanceOpeningException extends Exception {

}
