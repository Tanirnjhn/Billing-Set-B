package com.cg.feedback.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.feedback.beans.Trainer;
import com.cg.feedback.exception.NoTrainerfoundException;
import com.cg.feedback.util.DBUtil;

public class IFeedbackDao implements FeedbackDao {
    HashMap<Integer,Trainer> hm=DBUtil.getFeedbackList();
    
	@Override
	public void addfeedback(Trainer trainer) {
		int v=(int)(Math.random()*1000);
		hm.put(v, trainer);
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rate) throws NoTrainerfoundException {
		for(Map.Entry<Integer, Trainer> ter:hm.entrySet())
		{   
			if(rate==ter.getValue().getRating())
			{
				hm.put(ter.getKey(),ter.getValue());
			}
		}
		
		if(hm.isEmpty())
		{
			throw new NoTrainerfoundException();
		}
		else
		{
		return hm;
	}
 
	}

}
