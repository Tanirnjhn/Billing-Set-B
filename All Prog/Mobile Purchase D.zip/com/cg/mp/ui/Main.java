package com.cg.mp.ui;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.mp.bean.Customer;
import com.cg.mp.bean.Mobile;
import com.cg.mp.service.MobileImplements;
import com.pg.mp.exception.NotPurchaseException;
import com.pg.mp.exception.PriceNotAvailableException;

public class Main {
	
String mobName;
int mobileId;
float mobPrice;
int mobQuantity;
MobileImplements service;
public  Main()
 {
	System.out.println("Welcome to Mobile Shop");
	service=new MobileImplements();
 }
 public void  Menu()
 {
	 System.out.println("1.  View Mobile Details");
	 System.out.println("2.  Search Mobile Details on basis of price Range");
	 System.out.println("3. Enter Mobile id and Pucrchase quantity that you want to purchase");
	 System.out.println("4.  Puchase Mobile");
	 
	 Scanner scanner=new Scanner(System.in);
	 int choice=scanner.nextInt();
	
	 switch(choice)
	 {
	 case 1:System.out.println("List of all availble mobiles");
	           //service.view();
	         System.out.println(service.view());
	        break;
	 case 2: System.out.println("Enter the price range for your purchase");
	         try {
	           float price=scanner.nextFloat();
	               //service.search(price);
	           System.out.println( service.search(price));
	         }
	         catch(PriceNotAvailableException e)
	         {
	        	 System.out.println(e.getMessage());
	         }
	         break;
	         
	 case 3:System.out.println("If you want to purchase then enter mobile id and quantity");
	       try
	       {
		    //System.out.println("If you want to purchase then enter  ");
		    int mobileId=scanner.nextInt();
		    int mobQuantity=scanner.nextInt();
		    service.purchaseOrNot(mobileId,mobQuantity);
	       }
	       catch(NotPurchaseException e)
	       {
	    	System.out.println(e.getMessage());   
	       }
	       break;
	 case 4: System.out.println("Enter name ,mail,Phone Number,Date,mobileId,");
	 Customer c=new Customer();
	        	String name=scanner.next();
	        	String mail=scanner.next();
	        	String phoneNum=scanner.next();
	        	LocalDate date=LocalDate.now();
	        	int mobId=scanner.nextInt();
	            service.insert(name,mail,c.getPurchaseId(),phoneNum,date,mobileId);      	
	            System.out.println("Information added");	
	            break;
	   default: System.out.println("wrong Choice");
	            System.exit(0);
	            break;
	 }
	
 }
public static void main(String args[])
{
	Main main=new Main();
    	   main.Menu();
	
		
}

}
