package com.cg.mp.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import com.cg.mp.bean.Customer;
import com.cg.mp.bean.Mobile;

public interface IMobile {
	
	Customer insert(String custName,String Custmail,int purchaseId,String phoneNum,LocalDate date,int mobileId);// Adding customer to collection
	Map<Integer,Mobile> view(); // Displaying records
	Map<Integer, Mobile> search(float mobprice1); //VIewing details on basis of price range
    void purchaseOrNot(int mobileId,int mobQuantity);
	boolean IsVaildId(int mobId);

}
