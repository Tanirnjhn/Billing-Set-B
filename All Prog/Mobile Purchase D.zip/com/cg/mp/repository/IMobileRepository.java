package com.cg.mp.repository;

import java.util.List;
import java.util.Map;

import com.cg.mp.bean.Customer;
import com.cg.mp.bean.Mobile;

public interface IMobileRepository {
	 

	Customer add(Customer cusMap);
	 Map<Integer,Mobile> showMobDetails();
	 Map<Integer,Mobile> findByPrice(float mobprice1);
	boolean IsfindId(int mobileId);
	void updateQuanity(int mobId,int mobquantity);
}