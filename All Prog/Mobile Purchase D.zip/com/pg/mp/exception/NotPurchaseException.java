package com.pg.mp.exception;

public class NotPurchaseException extends RuntimeException{
	public NotPurchaseException(String msg)
	{
		super(msg);
	}

}
