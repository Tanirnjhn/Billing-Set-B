package com.pg.mp.exception;


public class InvalidCustNameException extends RuntimeException {
	public InvalidCustNameException(String msg)
	{
		super(msg);
	}

}

