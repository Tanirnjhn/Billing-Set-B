package com.cg.billinga2.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.billinga2.DAO.IProductDAO;
import com.cg.billinga2.DAO.ProductDAO;
import com.cg.billinga2.exception.ProductIdInvalidException;
import com.cg.billinga2.service.IProductService;
import com.cg.billinga2.service.ProductService;

class Tester {


	IProductService serv=new ProductService();
	
	@Test(expected=com.cg.billinga2.exception.ProductIdInvalidException.class)
	public void whenInvalidIdIsGivenSystemShouldThrowException() throws ProductIdInvalidException 
	{
//		assertEquals(1001, serv.getProductDetails());
		serv.getProductDetails(2222);
	}
	
	@Test
	public void whenValidIdIsGivenSystemShouldNotThrowException() throws ProductIdInvalidException 
	{
//		assertEquals(1001, serv.getProductDetails());
		serv.getProductDetails(1001);
}
	
}
