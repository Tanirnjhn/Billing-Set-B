package com.cg.billinga2.DAO;

import com.cg.billinga2.bean.Product;
import com.cg.billinga2.exception.ProductIdInvalidException;

public interface IProductDAO {
Product getProductDetails(int productCode) throws ProductIdInvalidException;
}
