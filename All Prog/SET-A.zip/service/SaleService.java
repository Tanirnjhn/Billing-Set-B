package com.capgemini.salesmanagement.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;

public class SaleService implements ISaleService {
public HashMap<Integer, Sale> product= new HashMap<>();


ISaleDAO isaledao = new SaleDAO();  
	

public SaleService( ISaleDAO isaledao) {
	super();
	
	this.isaledao = isaledao;
}

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		
		product=isaledao.insertSalesDetails(sale);
		System.out.println(product);

	return 	product;
	}

	
	@Override
	public boolean validateProductCode(int productId) {
		if(productId==1001|| productId==1002|| productId==1003|| productId==1004)
		return true;
		return false;
	
	}
	
	
	@Override
	public boolean validateQuantity(int qty) {
		
		if(qty>0 && qty<5)
		return true;
		  return false;
		}

	
	
	@Override
	public boolean validateproductCat(String prodCat) {
		
		if(prodCat.equals("Electronics") || prodCat.equals("Toys"))
			return true;
		
		return false;

		
		
		//		Pattern namePattern= Pattern.compile("^[A-Za-z]{4,}$");
//		Matcher nameMatcher= namePattern.matcher(prodCat);
//		
//		return nameMatcher.matches();
//	}

	}
	
	@Override
	public boolean validateProductName(String prodName , int flag) {
		
		if((flag==0 && prodName.equals("TV") || prodName.equals("Smart Phone") 
				|| prodName.equals("Video Game")) 
				|| (prodName.equals(" Soft Toy") || prodName.equals("Telescope")
						|| prodName.equals(" Barbee Doll")))
			
			
		return true;
			return false;
		
		

//		Pattern iproductName= Pattern.compile("^[A-Za-z]{4,}$");
//		Matcher prodNameMatcher= iproductName.matcher(prodName);
//		return prodNameMatcher.matches();
	}

	

	

	@Override
	public boolean validateProductPrice(float price) {
		if (price>200)
			return true;
		return false;
	}

}
