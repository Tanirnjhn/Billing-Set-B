package com.capgemini.salesmanagement.ui;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {

	public static void main(String[] args) {
  
  ISaleService saleservice=new SaleService(new SaleDAO());

 
   Scanner scanner= new Scanner(System.in);
   
   
   boolean check=true;
   int flag=1;
   System.out.println("enter product code");
   int prod= scanner.nextInt();
   scanner.nextLine();
   while(check)
   {
	   if(saleservice.validateProductCode(prod))
		 check= false;
   
   else
   {
	   System.out.println("Enter Valid code");
	   prod=scanner.nextInt();
	   scanner.nextLine();
   }
   }
   
   
   
	check=true;
	System.out.println("Enter Quantity");
	int qunt=scanner.nextInt();
	scanner.nextLine();
	while(check)
	{
		if(saleservice.validateQuantity(qunt))
		{
			check=false;
		}
		else
		{
			System.out.println("Quantity again enter");
			qunt=scanner.nextInt();
			scanner.nextLine();
		}
	}
   
	
	check=true;
	System.out.println("Enter product Category");
	String cat= scanner.nextLine();
	while(check)
	{
		if(saleservice.validateproductCat(cat))
			check=false;
		else
		{
			System.out.println("enter Category Again");
			cat=scanner.nextLine();
		}
	}
	
	
	check= true;
	System.out.println("Enter Product name");
	String name=scanner.nextLine();
	while(check)
	{
		if(saleservice.validateProductName(name, flag))
			check=false;
		else {
			System.out.println("enter valid product name");
			name=scanner.nextLine();

		}
	}
	
	
	check=true;
	System.out.println("enter Product Price");
	float price=scanner.nextFloat();
	scanner.nextLine();
	while(check)
	{
		if(saleservice.validateProductPrice(price))
			check=false;
		else
		{
			System.out.println("enter valid price");
			price= scanner.nextFloat();
			scanner.nextLine();
		}
	}
	
	int saleid= (int)Math.random()*1000+1;
	Sale sale= new Sale();
	sale.setSaleId(saleid);
	sale.setQuantity(qunt);
	sale.setCategory(cat);
	sale.setProdCode(prod);
	sale.setProductName(name);
    sale.setSaleDate(LocalDate.now());
	sale.setLineTotal(price*qunt);
	
	
	System.out.println("Quantity is:"+ sale.getQuantity());
	System.out.println("Total :"+ sale.getLineTotal());
	
	System.out.println("*"+ saleservice.insertSalesDetails(sale));
	
	
	
	
}
}
