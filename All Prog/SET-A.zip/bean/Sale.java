package com.capgemini.salesmanagement.bean;

import java.time.LocalDate;

public class Sale {
	
	private int saleId;
	private int prodCode;
	private String productName;
	private String category;
	private LocalDate saleDate;
	private int quantity;
	private float lineTotal;
	private String productDescription;
	public Sale()
	{
		super();
	}
	
	
	public Sale(int saleId, int prodCode, String productName, String category, LocalDate saleDate, int quantity,
			float lineTotal, String productDescription) {
		super();
		this.saleId = saleId;
		this.prodCode = prodCode;
		this.productName = productName;
		this.category = category;
		this.saleDate = saleDate;
		this.quantity = quantity;
		this.lineTotal = lineTotal;
		this.productDescription = productDescription;
	}


	public int getSaleId() // Getter setter for SaleId
	{
		return saleId;
	}
	public void setSaleId(int saleid)
	{
		this.saleId = saleId;
	}
	public int getProdCode()   // Getter for prodCode
	{
		return prodCode;
	}
	public void setProdCode(int prodCode) // setter for prodCode
	
	{
		this.prodCode = prodCode;
	}
	public String getProductName()     // Getter setter for productName
{
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCategory()     // Getter setter for category
	{
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public LocalDate getSaleDate()           // Getter setter for SaleDate
	{
		return saleDate;
	}
	public void setSaleDate(LocalDate saleDate) {
		this.saleDate = saleDate;
	} 
	public int getQuantity()             //Getter setter for quantity
	{
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getLineTotal()      //Getter setter for lineTotal
	{
		return lineTotal;
	}
	public void setLineTotal(float lineTotal) {
		this.lineTotal = lineTotal;
	}
	@Override
	public String toString() {
		return "Sale [saleId=" + saleId + ", prodCode=" + prodCode + ", productName=" + productName + ", category="
				+ category + ", saleDate=" + saleDate + ", quantity=" + quantity + ", lineTotal=" + lineTotal + "]";
	}

	
	

}
