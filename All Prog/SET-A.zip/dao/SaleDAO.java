package com.capgemini.salesmanagement.dao;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;

public class SaleDAO implements ISaleDAO{
	HashMap<Integer,Sale> Details= new HashMap<>();
	
	

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		Details.put(sale.getSaleId(), sale);
		return Details;
		

	}

}
