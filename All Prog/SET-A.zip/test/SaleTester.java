package com.capgemini.salesmanagement.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class SaleTester {
 
	ISaleService saleSr=new SaleService(new SaleDAO());
	@Test
	public void WhenInvalidCodeIsEnteredSystemReturnsFalse() {
		
	assertEquals(false,saleSr.validateProductCode(100));
	}
	
	@Test
	public void WhenValidCodeIsEnterSystemReturnTrue()
	{
		assertEquals(true, saleSr.validateProductCode(1001));
	}{
		
	}

}
