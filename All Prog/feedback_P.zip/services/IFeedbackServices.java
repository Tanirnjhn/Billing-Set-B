package com.cg.feedback.services;

import java.util.HashMap;

import com.cg.feedback.beans.Trainer;
import com.cg.feedback.dao.FeedbackDao;
import com.cg.feedback.dao.IFeedbackDao;

public class IFeedbackServices implements FeedbackServices {
    FeedbackDao repo=new IFeedbackDao();
	@Override
	public void addfeedback(Trainer trainer) {
		
		repo.addfeedback(trainer);
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		
		return repo.getTrainerList();
	}

}
