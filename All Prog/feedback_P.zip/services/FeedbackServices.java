package com.cg.feedback.services;

import java.util.HashMap;

import com.cg.feedback.beans.Trainer;

public interface FeedbackServices {
	 public void addfeedback(Trainer trainer);
	  public HashMap<Integer,Trainer> getTrainerList();
}
