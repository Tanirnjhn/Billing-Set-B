package com.cg.feedback.dao;

import java.util.HashMap;

import com.cg.feedback.beans.Trainer;

public interface FeedbackDao {
  public void addfeedback(Trainer trainer);
  public HashMap<Integer,Trainer> getTrainerList();
}
