package com.cg.feedback.dao;

import java.util.HashMap;

import com.cg.feedback.beans.Trainer;
import com.cg.feedback.util.DBUtil;

public class IFeedbackDao implements FeedbackDao {
 HashMap<Integer,Trainer> hm;
	@Override
	public void addfeedback(Trainer trainer) {
		hm=DBUtil.feedbackList;
		int a=(int)(Math.random()*1000);
		hm.put(a, trainer);
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		hm=DBUtil.feedbackList;
		return hm;
	}

}
