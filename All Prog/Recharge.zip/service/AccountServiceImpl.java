package com.cpg.Recharge.service;

import com.cpg.Recharge.bean.Account;
import com.cpg.Recharge.dao.AccountDaoImpl;
import com.cpg.Recharge.exception.InvalidMobileNumberException;

public class AccountServiceImpl implements AccountService {
	private AccountDaoImpl DAo; 
	public AccountServiceImpl(AccountDaoImpl dAo) {
	super();
	DAo = dAo;
}

	@Override
	public Account getAccountDetails(String mobileNo)throws InvalidMobileNumberException {

		return DAo.getAccountDetails(mobileNo) ;
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount)throws InvalidMobileNumberException {
		// TODO Auto-generated method stub
		return DAo.rechargeAccount(mobileNo, rechargeAmount);
	}

}
