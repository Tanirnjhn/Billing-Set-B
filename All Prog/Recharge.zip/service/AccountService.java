package com.cpg.Recharge.service;

import com.cpg.Recharge.bean.Account;
import com.cpg.Recharge.exception.InvalidMobileNumberException;

public interface AccountService {
	Account getAccountDetails(String mobileNo)throws InvalidMobileNumberException;
	int rechargeAccount(String mobileNo, double rechargeAmount)throws InvalidMobileNumberException;


}
