package com.cpgi.PaytmWallet.test;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import javax.naming.InvalidNameException;

import org.junit.Test;

import com.cpgi.PaytmWallet.bean.Wallet;
import com.cpgi.PaytmWallet.exception.DuplicateMobileNumberException;
import com.cpgi.PaytmWallet.exception.InsufficientBalanceException;
import com.cpgi.PaytmWallet.exception.InvalidPhoneNumberException;
import com.cpgi.PaytmWallet.repository.WalletRepoImp;
import com.cpgi.PaytmWallet.service.WalletServiceImp;
import com.cpgi.PaytmWallet.service.WalletServiceInterface;

public class Testing 
{
	WalletServiceInterface service= new WalletServiceImp(new WalletRepoImp());
// -------------------------------------CREATE ACCOUNT------------------------------------------------------
	@Test(expected=com.cpgi.PaytmWallet.exception. DuplicateMobileNumberException.class)
	public void tester()throws  DuplicateMobileNumberException{
		service.CreateAccount("tani"," 7830447679",new Wallet(new BigDecimal("5000.0")));
		service.CreateAccount("tanisha", "7830447679", new Wallet(new BigDecimal("5980.00")));
	}
	
	
	
@Test
public void tester1()throws  DuplicateMobileNumberException
{
	service.CreateAccount("tan", "7830447679", new Wallet(new BigDecimal("2000.00")));
}

//-------------------------------SHOW BALANCE-------------------------------------------------------------------------------

//When Invalid Mobile Number Is Passed To ShowBalance ThrowException
@Test(expected=com.cpgi.PaytmWallet.exception.InvalidPhoneNumberException.class)
public void WhenInvalidMobileNumberIsPassedToShowBalanceThrowException() throws InvalidPhoneNumberException,InsufficientBalanceException,DuplicateMobileNumberException
{
	service.CreateAccount("Suraj", "9897934489", new Wallet(new BigDecimal("20000.00")));
	service.ShowBalance("999999999");
}


//When Invalid Mobile Number Is Passed, Show Balance Successfully
@Test
public void WhenValidMobileNumberIsPassedShowBalanceSuccessfully() throws InvalidPhoneNumberException,InsufficientBalanceException,DuplicateMobileNumberException
{
	service.CreateAccount("Suraj", "9897934489", new Wallet(new BigDecimal("20000.00")));
	service.ShowBalance("9897934489");
}




//-------------------------------WITHDRAW AMOUNT------------------------------------------------------------------------------

//When Invalid Mobile Number Is Passed To Withdraw Amount ThrowException

@Test(expected=com.cpgi.PaytmWallet.exception. InvalidPhoneNumberException.class)
public void WhenInvalidMobileNumberIsPassedToWithdrawAmountThrowException() throws  InvalidPhoneNumberException,InsufficientBalanceException
{
	Wallet wallet=new Wallet();
	service.CreateAccount("Suraj", "9897934489", new Wallet(new BigDecimal("20000.00")));
	service.Withdraw("9999999999", new BigDecimal("10000.00"));
}


//When Valid Mobile Number Is Passed, Show Balance Successfully



//-------------------------------DEPOSIT AMOUNT-----------------------------------------------------------------------------

//When Invalid Mobile Number Is Passed To Deposit Amount ThrowException

@Test(expected=com.cpgi.PaytmWallet.exception. InvalidPhoneNumberException.class)
public void WhenInvalidMobileNumberIsPassedToDepositAmountThrowException() throws  InvalidPhoneNumberException,InsufficientBalanceException,DuplicateMobileNumberException
{
	service.CreateAccount("Suraj", "9897934489", new Wallet(new BigDecimal("20000.00")));
	service.Deposit("9999999999", new BigDecimal("2000.0"));
}

//When Valid Mobile Number Is Passed, Deposit Amount Successfully

@Test
public void WhenValidMobileNumberIsPassedDepositAmountSuccessfully() throws  InvalidPhoneNumberException,InsufficientBalanceException,DuplicateMobileNumberException
{
	service.CreateAccount("Suraj", "9897934489", new Wallet(new BigDecimal("20000.00")));
	service.Deposit("9897934489", new BigDecimal("5000.0"));
}


//-------------------------------FUND TRANSFER-----------------------------------------------------------------------------

//When Invalid Mobile Number Is Passed ThrowException
@Test(expected=com.cpgi.PaytmWallet.exception. InvalidPhoneNumberException.class)
public void WhenInvalidMobileNumberIsPassedToFundTransferThrowException() throws InvalidPhoneNumberException,InsufficientBalanceException,DuplicateMobileNumberException
{
	service.CreateAccount("Suraj", "9897934489", new Wallet(new BigDecimal("100.00")));
	service.CreateAccount("Vansh", "8888888888", new Wallet(new BigDecimal("50.00")));
	service.FundTransfer("9897934489", (new BigDecimal("50.00")) ,"7777777777");
}

//When Valid Mobile Number Is Passed, Fund Transfer Successfully
	@Test
	public void WhenValidMobileNumberIsPassedFundTransferSuccessfully() throws InvalidPhoneNumberException,InsufficientBalanceException,DuplicateMobileNumberException
	{
		service.CreateAccount("Suraj", "9897934489", new Wallet(new BigDecimal("100.00")));
		service.CreateAccount("Vansh", "8888888888", new Wallet(new BigDecimal("50.00")));
		service.FundTransfer("9897934489", (new BigDecimal("50.00")), "8888888888");
	}
}
