package com.cpgi.PaytmWallet.repository;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.cpgi.PaytmWallet.bean.Customer;
import com.cpgi.PaytmWallet.exception.InvalidPhoneNumberException;

public class WalletRepoImp implements WalletRepointerface {
private Map<String, Customer> customer= new HashMap();
	@Override
	public boolean Save(Customer c) {
		if(customer.containsKey(c.getMobileNo()))
		{
			return false;
		}
		else
		{
		customer.put(c.getMobileNo(), c);
		return true;
		}
	}
	@Override
	public Customer FindByPhone(String MobileNo) throws InvalidPhoneNumberException {
		
			for(Entry<String, Customer> entry: customer.entrySet())
			{
				if(entry.getKey().equals(MobileNo))
				{
					return entry.getValue();
				}
			}
			throw new InvalidPhoneNumberException();
		}

	}

	

	