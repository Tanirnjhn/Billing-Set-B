package com.cpgi.PaytmWallet.view;

import java.math.BigDecimal;

import javax.naming.InvalidNameException;


import com.cpgi.PaytmWallet.bean.Wallet;
import com.cpgi.PaytmWallet.repository.WalletRepoImp;
import com.cpgi.PaytmWallet.repository.WalletRepointerface;
import com.cpgi.PaytmWallet.exception.DuplicateMobileNumberException;
import com.cpgi.PaytmWallet.exception.InsufficientBalanceException;
import com.cpgi.PaytmWallet.exception.InvalidPhoneNumberException;
import com.cpgi.PaytmWallet.service.WalletServiceImp;
import com.cpgi.PaytmWallet.service.WalletServiceInterface;

public class Main2 {

	public static void main(String args[])throws Exception
	{
		WalletServiceInterface walletservice=new WalletServiceImp(new WalletRepoImp());
	
	try
	{
			System.out.println(walletservice.CreateAccount("TAni", "9876543123", new Wallet(new BigDecimal("5000"))));
			System.out.println(walletservice.CreateAccount("TAn", "9876543103", new Wallet(new BigDecimal("5078"))));
			System.out.println(walletservice.CreateAccount("TAnisha", "9876543623", new Wallet(new BigDecimal("7000"))));
			System.out.println(walletservice.ShowBalance("9876543123"));
			System.out.println(walletservice.Deposit("9876543143", new BigDecimal("5000")));
			System.out.println(walletservice.Withdraw("9876543623",new BigDecimal("5700")));
			System.out.println(walletservice.FundTransfer("9876543623",new BigDecimal("5000"),"9876543143"));
	}
	
	catch(InvalidPhoneNumberException e)
	{ 
System.out.println("InvalidPhoneNumberException");

	}
	catch(InsufficientBalanceException ee)
	{
		System.out.println("InsufficientBalanceException");
	} 
	catch( DuplicateMobileNumberException eee)
	{
		System.out.println(" DuplicateMobileNumberException");
	}
}
}