package com.cpgi.PaytmWallet.exception;

public class DuplicateMobileNumberException extends Exception {

}
