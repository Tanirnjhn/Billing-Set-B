package com.cpgi.PaytmWallet.exception;

public class InvalidPhoneNumberException extends Exception {

}
