package com.capgemini.recharge.dao;

import java.util.List;

import com.capgemini.recharge.bean.Account;
import com.capgemini.recharge.bean.Option;

public interface AccountDAO {
	public List<Account> findAll();
	public List<Account> sortAccountDetails(Option option);
	public boolean create(Account newAccount);

	public boolean delete(int id);
	public boolean update(int id, Account account);
	public Account findById(int id);

}
