package com.cg.BankAcc.ui;

public class InvalidAccountNumberException extends Exception {

}
